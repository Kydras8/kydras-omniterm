#!/usr/bin/env zsh
set -euo pipefail
setopt NO_BANG_HIST
emulate -L zsh

PREFIX="${PREFIX:-$HOME/.local}"
BIN="$PREFIX/bin"

echo "[omnterm] installing to $BIN"
mkdir -p "$BIN"

SRC_DIR="$(cd -- "$(dirname -- "$0")" && pwd)"
# If run via curl | zsh, $0 is -zsh; try to fetch from GitHub raw as fallback
if [[ -f "$SRC_DIR/bin/poly" ]]; then
  cp -f "$SRC_DIR/bin/poly" "$BIN/poly"
else
  # Fallback: try to pull from main branch of the repo
  RAW_URL="${RAW_URL:-https://raw.githubusercontent.com/YOUR_GITHUB/kydras-omniterm/main/bin/poly}"
  curl -fsSL "$RAW_URL" -o "$BIN/poly"
fi

chmod +x "$BIN/poly"

case ":$PATH:" in
  *":$BIN:"*) ;;
  *) echo 'export PATH="$HOME/.local/bin:$PATH"' >> "$HOME/.zshrc" ;;
esac

echo "[omnterm] installed: $(command -v poly || echo "$BIN/poly")"
echo "[omnterm] restart your shell or run: exec zsh -l"
