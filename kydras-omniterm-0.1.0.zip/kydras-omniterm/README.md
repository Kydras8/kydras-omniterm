# Kydras OmniTerm

A tiny **polyglot terminal runner**: route code to the right interpreter with a `:lang` tag (defaults to zsh).

- One command: `poly`
- Supported: zsh, bash, python, node, ruby, php, go, c, c++, rust, java, lua
- Optional `--sandbox` with **firejail** (if installed) for a private, no-network jail

## Install

```zsh
# Option A: quick installer (to ~/.local/bin)
curl -fsSL https://raw.githubusercontent.com/YOUR_GITHUB/kydras-omniterm/main/install.sh | zsh

# Option B: manual
chmod +x bin/poly
mkdir -p ~/.local/bin
cp bin/poly ~/.local/bin/
echo 'export PATH="$HOME/.local/bin:$PATH"' >> ~/.zshrc
exec zsh -l
```
> Replace `YOUR_GITHUB` after you publish the repo.

## Usage

```zsh
poly :py 'print(2+2)'
poly :js 'console.log(42)'
poly :bash 'for i in {1..3}; do echo $i; done'
poly :go $'package main\nimport "fmt"\nfunc main(){fmt.Println("hi")}'
poly :c $'#include <stdio.h>\nint main(){puts("hi");}'

# read multi-line from stdin
poly :py - <<'PY'
import sys
print("hello polyterm", sys.version.split()[0])
PY

# run in a simple sandbox (if firejail is available)
poly --sandbox :py 'print("sandboxed")'
```

## Languages

| Tag | Language/Tool | Notes |
|-----|---------------|-------|
| `zsh`, `sh` | Z shell | default when no tag provided |
| `bash` | Bash |  |
| `py`, `python` | Python 3 | uses `python3` |
| `js`, `node` | Node.js | uses `node` |
| `rb`, `ruby` | Ruby | uses `ruby` |
| `php` | PHP | uses temp file for multi-line |
| `go`, `golang` | Go | `go run` |
| `c` | C (gcc) | compiles to temp binary |
| `cpp`, `cxx`, `cc` | C++17 (g++) | compiles to temp binary |
| `rs`, `rust` | Rust | `rustc` |
| `java` | Java | `javac` then `java` in temp dir |
| `lua` | Lua | `lua` |

## Development

```zsh
# run quick tests (requires zsh, node, python3, etc.)
zsh test/test-quick.zsh
```

## License

MIT © 2025-08-18 Kydras Systems Inc.
