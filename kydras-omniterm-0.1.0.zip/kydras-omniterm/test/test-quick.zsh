#!/usr/bin/env zsh
set -euo pipefail
setopt NO_BANG_HIST

export PATH="$(pwd)/bin:$PATH"

echo "[test] zsh echo"
poly :zsh 'echo ZOK' | grep -q ZOK

echo "[test] python add"
poly :py 'print(2+3)' | grep -q 5

if command -v node >/dev/null 2>&1; then
  echo "[test] node console"
  poly :js 'console.log(7*6)' | grep -q 42
fi

if command -v gcc >/dev/null 2>&1; then
  echo "[test] c hello"
  poly :c $'#include <stdio.h>\nint main(){puts("COK");}' | grep -q COK
fi

echo "[test] DONE"
