## v3.0.0 — Themes

- **Theming** for tmux via `omniterm --theme <name>`
- **Prompt themes** for zsh panes (auto-loaded if `OMNITERM_ZSH_THEME` is set)
- Bundled themes: `kydras-pro`, `dracula`, `solarized-dark`

### Use
```zsh
omniterm start --session kydras --profile kydras --theme kydras-pro
omniterm theme dracula
omniterm theme solarized-dark
```

### Zsh integration
Add to the end of your ~/.zshrc:
```zsh
if [[ -n ${OMNITERM_ZSH_THEME:-} ]]; then
  for dir in "$HOME/.config/omniterm" "$HOME/.local/share/omniterm/themes/zsh" "$HOME/.local/share/omniterm/themes"; do
    f="$dir/zsh-theme-${OMNITERM_ZSH_THEME}.zsh"
    [[ -r "$f" ]] && source "$f" && break
  done
fi
```
