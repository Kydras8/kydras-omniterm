# zsh theme: kydras-pro
autoload -Uz colors; colors
setopt PROMPT_SUBST
git_branch() { local b; b=$(git rev-parse --abbrev-ref HEAD 2>/dev/null) || return; print -rn -- "%F{46}⎇%f %F{46}${b}%f "; }
exit_mark() { (( $? == 0 )) && print -rn "" || print -rn "%F{196}✘%f "; }
PROMPT='%F{39}%*%f %F{81}%n@%m%f %F{245}%~%f $(git_branch)
%F{82}❯%f '
RPROMPT='$(exit_mark)'
