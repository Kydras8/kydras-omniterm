# zsh theme: solarized-dark
autoload -Uz colors; colors
setopt PROMPT_SUBST
git_branch(){ b=$(git rev-parse --abbrev-ref HEAD 2>/dev/null) || return; print -rn -- "%F{136}${b}%f"; }
PROMPT='%F{136}%n@%m%f %F{244}%~%f
%F{136}$%f '
RPROMPT='$(git_branch) %F{244}%*%f'
