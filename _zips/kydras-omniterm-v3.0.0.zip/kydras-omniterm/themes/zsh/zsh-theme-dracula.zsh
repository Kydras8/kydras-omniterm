# zsh theme: dracula
autoload -Uz colors; colors
setopt PROMPT_SUBST
git_branch(){ b=$(git rev-parse --abbrev-ref HEAD 2>/dev/null) || return; print -rn -- "%F{141}${b}%f"; }
PROMPT='%F{141}%n%f@%F{117}%m%f %F{249}%~%f
%F{141}➜%f '
RPROMPT='$(git_branch) %F{249}%*%f'
